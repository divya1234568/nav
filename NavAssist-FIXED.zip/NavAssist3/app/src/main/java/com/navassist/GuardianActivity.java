package com.navassist;

import android.os.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.*;

public class GuardianActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guardian);

        findViewById(R.id.btn_back_guardian).setOnClickListener(v -> finish());
        findViewById(R.id.btn_call).setOnClickListener(v ->
            Toast.makeText(this, "📞 Calling...", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btn_msg).setOnClickListener(v ->
            Toast.makeText(this, "💬 Message sent!", Toast.LENGTH_SHORT).show());

        // Simulate live location updates
        TextView tvLoc = findViewById(R.id.tv_guardian_loc);
        TextView tvTime = findViewById(R.id.tv_guardian_time);
        String[] locs = {"Anna Nagar, Chennai", "Koyambedu, Chennai", "Arumbakkam, Chennai"};
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            int i = 0;
            public void run() {
                tvLoc.setText("📍 " + locs[i % locs.length]);
                tvTime.setText("Updated " + new SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(new Date()));
                i++;
                new Handler(Looper.getMainLooper()).postDelayed(this, 5000);
            }
        }, 3000);
    }
}
