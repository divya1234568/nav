package com.navassist;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.*;
import android.speech.tts.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.*;
import com.google.mlkit.vision.objects.*;
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CameraActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private PreviewView previewView;
    private TextView tvResults;
    private Button btnSpeak, btnBack, btnToggle;
    private TextToSpeech tts;
    private ExecutorService executor;
    private boolean textMode = false;
    private long lastSpeak = 0;
    private String lastResult = "";
    private Vibrator vibrator;
    private String mode;

    private ObjectDetector objectDetector;
    private ImageLabeler imageLabeler;
    private TextRecognizer textRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        mode     = getIntent().getStringExtra(SplashActivity.EXTRA_MODE);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        tts      = new TextToSpeech(this, this);
        executor = Executors.newSingleThreadExecutor();

        previewView = findViewById(R.id.camera_preview);
        tvResults   = findViewById(R.id.tv_results);
        btnSpeak    = findViewById(R.id.btn_speak);
        btnBack     = findViewById(R.id.btn_back_cam);
        btnToggle   = findViewById(R.id.btn_toggle);

        btnBack.setOnClickListener(v -> finish());
        btnSpeak.setOnClickListener(v -> speak(tvResults.getText().toString()));
        btnToggle.setOnClickListener(v -> {
            textMode = !textMode;
            btnToggle.setText(textMode ? "🔍 Objects" : "📝 Read Text");
            speak(textMode ? "Text reading mode. Point at signs or labels." : "Object detection mode.");
        });

        setupMLKit();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 10);
        }
    }

    private void setupMLKit() {
        objectDetector = ObjectDetection.getClient(new ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableMultipleObjects()
            .enableClassification()
            .build());

        imageLabeler = ImageLabeling.getClient(new ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.7f).build());

        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    private void startCamera() {
        ProcessCameraProvider.getInstance(this).addListener(() -> {
            try {
                ProcessCameraProvider provider = ProcessCameraProvider.getInstance(this).get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build();
                analysis.setAnalyzer(executor, this::analyze);

                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @androidx.camera.core.ExperimentalGetImage
    private void analyze(ImageProxy proxy) {
        if (proxy.getImage() == null) { proxy.close(); return; }

        InputImage image = InputImage.fromMediaImage(
            proxy.getImage(), proxy.getImageInfo().getRotationDegrees());

        if (textMode) {
            textRecognizer.process(image)
                .addOnSuccessListener(result -> {
                    String text = result.getText().trim();
                    if (!text.isEmpty()) updateResult("📝 TEXT:\n" + text, text, 4000);
                })
                .addOnCompleteListener(t -> proxy.close());
        } else {
            objectDetector.process(image)
                .addOnSuccessListener(objects -> {
                    List<String> lines = new ArrayList<>();
                    for (DetectedObject obj : objects) {
                        String label = obj.getLabels().isEmpty() ? "Object" : obj.getLabels().get(0).getText();
                        int conf = obj.getLabels().isEmpty() ? 0 : (int)(obj.getLabels().get(0).getConfidence()*100);
                        String pos = getPosition(obj.getBoundingBox(), proxy.getWidth(), proxy.getHeight());
                        lines.add("• " + label + " (" + conf + "%) — " + pos);
                    }
                    if (!lines.isEmpty()) {
                        String display = String.join("\n", lines);
                        String spoken = lines.get(0).replace("•","").replaceAll("\\(\\d+%\\)","").trim();
                        updateResult(display, spoken, 3000);
                    }
                })
                .addOnFailureListener(e -> {})
                .addOnCompleteListener(t -> proxy.close());
        }
    }

    private String getPosition(Rect box, int w, int h) {
        float cx = box.centerX() / (float) w;
        float area = (float)(box.width() * box.height()) / (w * h);
        String side = cx < 0.35f ? "on your left" : cx > 0.65f ? "on your right" : "ahead";
        String dist = area > 0.25f ? "very close" : area > 0.08f ? "nearby" : "far ahead";
        return side + ", " + dist;
    }

    private void updateResult(String display, String spoken, long cooldown) {
        runOnUiThread(() -> tvResults.setText(display));
        long now = System.currentTimeMillis();
        if (now - lastSpeak > cooldown && !spoken.equals(lastResult)) {
            lastSpeak = now;
            lastResult = spoken;
            speak(spoken);
            vibrateShort();
        }
    }

    public void speak(String t) {
        if (tts != null && !SplashActivity.MODE_DEAF.equals(mode))
            tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    private void vibrateShort() {
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE));
        else vibrator.vibrate(60);
    }

    @Override public void onInit(int s) {
        if (s == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.US);
            speak("Camera ready. I will identify objects around you automatically.");
        }
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) startCamera();
    }

    @Override protected void onDestroy() {
        executor.shutdown();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
