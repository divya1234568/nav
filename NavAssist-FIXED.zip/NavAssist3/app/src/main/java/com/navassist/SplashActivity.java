package com.navassist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    public static final String EXTRA_MODE = "mode";
    public static final String MODE_BLIND    = "blind";
    public static final String MODE_DEAF     = "deaf";
    public static final String MODE_MOBILITY = "mobility";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        findViewById(R.id.card_blind).setOnClickListener(v -> launch(MODE_BLIND));
        findViewById(R.id.card_deaf).setOnClickListener(v -> launch(MODE_DEAF));
        findViewById(R.id.card_mobility).setOnClickListener(v -> launch(MODE_MOBILITY));
        findViewById(R.id.card_guardian).setOnClickListener(v -> {
            startActivity(new Intent(this, GuardianActivity.class));
        });
    }

    private void launch(String mode) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra(EXTRA_MODE, mode);
        startActivity(i);
    }
}
