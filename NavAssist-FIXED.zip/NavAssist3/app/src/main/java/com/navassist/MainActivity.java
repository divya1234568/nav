package com.navassist;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.*;
import android.speech.*;
import android.speech.tts.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.util.*;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private TextToSpeech tts;
    private Vibrator vibrator;
    private String mode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mode     = getIntent().getStringExtra(SplashActivity.EXTRA_MODE);
        if (mode == null) mode = SplashActivity.MODE_BLIND;
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        tts      = new TextToSpeech(this, this);

        ActivityCompat.requestPermissions(this, new String[]{
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.SEND_SMS
        }, 1);

        // Mode badge
        TextView badge = findViewById(R.id.tv_mode_badge);
        switch (mode) {
            case SplashActivity.MODE_BLIND:    badge.setText("👁 BLIND MODE");    break;
            case SplashActivity.MODE_DEAF:     badge.setText("👂 DEAF MODE");     break;
            case SplashActivity.MODE_MOBILITY: badge.setText("♿ MOBILITY MODE"); break;
        }

        // Buttons
        findViewById(R.id.btn_sos).setOnClickListener(v -> {
            vibrate(400);
            startActivity(new Intent(this, SOSActivity.class));
        });

        findViewById(R.id.btn_camera).setOnClickListener(v -> {
            speak("Opening camera scanner. I will identify everything around you.");
            vibrate(100);
            startActivity(new Intent(this, CameraActivity.class)
                .putExtra(SplashActivity.EXTRA_MODE, mode));
        });

        findViewById(R.id.btn_voice).setOnClickListener(v -> startVoice());

        findViewById(R.id.btn_navigate).setOnClickListener(v -> {
            speak("Navigation started. Turn right in 50 meters.");
            vibrate(200);
            Toast.makeText(this, "🗺 Navigation started!", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btn_guardian).setOnClickListener(v ->
            startActivity(new Intent(this, GuardianActivity.class)));

        findViewById(R.id.btn_nearby).setOnClickListener(v -> {
            speak("Searching for nearby hospitals and accessible places.");
            Toast.makeText(this, "Searching nearby places...", Toast.LENGTH_SHORT).show();
        });
    }

    private void startVoice() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a command...");
        try { startActivityForResult(i, 99); }
        catch (Exception e) { Toast.makeText(this, "Voice not available", Toast.LENGTH_SHORT).show(); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 99 && res == RESULT_OK && data != null) {
            String cmd = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).get(0).toLowerCase();
            if (cmd.contains("scan") || cmd.contains("camera"))   { startActivity(new Intent(this, CameraActivity.class)); }
            else if (cmd.contains("sos") || cmd.contains("help")) { startActivity(new Intent(this, SOSActivity.class)); }
            else if (cmd.contains("guardian"))                     { startActivity(new Intent(this, GuardianActivity.class)); }
            else if (cmd.contains("navigate") || cmd.contains("home")) { speak("Navigation started. Turn right in 50 meters."); }
            else speak("Command not understood. Try: scan, sos, guardian, or navigate.");
        }
    }

    public void speak(String text) {
        if (tts != null && !SplashActivity.MODE_DEAF.equals(mode))
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    private void vibrate(long ms) {
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
        else
            vibrator.vibrate(ms);
    }

    @Override public void onInit(int s) {
        if (s == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.US);
            speak("NavAssist ready. Tap the camera button to scan your surroundings.");
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
